﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MazeJalma
{

    public partial class Form1 : Form
    {
        bool moveRight,moveLeft,moveUp,moveDown;

        private Bitmap soldierimage = Properties.Resources.survivor_move_knife_12;
        private Bitmap mapimage = Properties.Resources.background;
        private Graphics g = null;
        private Graphics g2 = null;

        Bitmap bmp = null;
        Bitmap btmp = null;
        int speedx = 0;
        int speedy = 0;

        public Form1()
        {
            InitializeComponent();

            int x = 0;
            int y = 0;

            Timer tm = new Timer();
            tm.Interval = 20;


            this.Load += delegate
            {
                pictureBox2.SendToBack();
                bmp = new Bitmap(soldierimage, soldierimage.Width, soldierimage.Height);
                g2 = Graphics.FromImage(pictureBox2.Image);
                g = Graphics.FromImage(bmp);
             
                tm.Start();
            };
            this.KeyDown += (s, e) =>
            {
                switch (e.KeyCode)
                {
                    case Keys.Escape:
                        Application.Exit();
                        break;
                    case Keys.A:
                        speedx = -18;
                        break;
                    case Keys.D:
                        speedx = 18;
                        break;
                    case Keys.W:
                        speedy = -18;
                        break;
                    case Keys.S:
                        speedy = 18;
                        break;
                }
            };
            this.KeyUp += (s, e) =>
            {
                switch (e.KeyCode)
                {
                    case Keys.Escape:
                        Application.Exit();
                        break;
                    case Keys.A:
                        speedx = 0;
                        break;
                    case Keys.D:
                        speedx = 0;
                        break;
                    case Keys.W:
                        speedy = 0;
                        break;
                    case Keys.S:
                        speedy = 0;
                        break;
                }
            };
            tm.Tick += delegate
            {
                x += speedx;
                y += speedy;
                if (x < 0)
                    x = 0;
                if (y < 0)
                    y = 0;
                moveMap(x, y);
                RotateSoldier(angle);
                pictureBox2.Refresh();
            };
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        float angle = 0;
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            Point center = new Point(this.Width / 2, this.Height / 2) ;
            angle = (float)Math.Atan2(e.Y - center.Y, e.X - center.X) * (float)(180/Math.PI);
        }

        public void RotateSoldier(float rotationAngle)
        {
            int deslocx = pictureBox2.Width / 2;
            int deslocy = pictureBox2.Height / 2;

            g2.TranslateTransform(deslocx, deslocy);
            g2.RotateTransform(rotationAngle);

            g2.DrawImage(soldierimage, 
                new Rectangle(-soldierimage.Width / 2, -soldierimage.Height / 2, soldierimage.Width, soldierimage.Height), 
                new Rectangle(0, 0, soldierimage.Width, soldierimage.Height), 
                GraphicsUnit.Pixel);

            g2.RotateTransform(-rotationAngle);
            g2.TranslateTransform(-deslocx, -deslocy);
        }
        public void moveMap(int x, int y)
        {
            g2.Clear(Color.Transparent);
            g2.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g2.DrawImage(mapimage, new Rectangle(0, 0, pictureBox2.Width, pictureBox2.Height),
                new Rectangle(x, y, pictureBox2.Width, pictureBox2.Height), GraphicsUnit.Pixel);
        }
    }
}
