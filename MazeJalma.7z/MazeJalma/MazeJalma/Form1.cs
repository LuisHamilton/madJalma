﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MazeJalma
{

    public partial class Form1 : Form
    {


        bool moveRight,moveLeft,moveUp,moveDown;

        private Bitmap soldierimage = Properties.Resources.survivor_move_knife_12;


        int speed = 8;

        public Form1()
        {
            InitializeComponent();

            PictureBox pb = pictureBox1;
            PictureBox f = new PictureBox();
            f.Dock = DockStyle.Fill;
            this.Controls.Add(pb);

            Bitmap bmp = null;
            Bitmap btmp = null;
            Graphics g = null;
            Timer tm = new Timer();
            tm.Interval = 1;

            this.BackgroundImage = null;

            this.Load += delegate
            {
                bmp = new Bitmap(Properties.Resources.survivor_move_knife_12, pb.Width, pb.Height);
                btmp = new Bitmap(pb.Width, pb.Height);
                g = Graphics.FromImage(btmp);
             
                tm.Start();
            };
            tm.Tick += delegate
            {
                Image bg = Properties.Resources.background;
                PointF ulCorner = new PointF(100.0F, 100.0F);
                g.DrawImage(bg, ulCorner);
                f.Image = btmp;
                pb.Image = bmp;
                this.KeyDown += (s, e) =>
                {
                    switch (e.KeyCode)
                    {
                        case Keys.Escape:
                            Application.Exit();
                            break;
                        case Keys.A:
                            moveLeft = true;
                            break;
                        case Keys.D:
                            moveRight = true;
                            break;
                        case Keys.W:
                            moveUp = true;
                            break;
                        case Keys.S:
                            moveDown = true;
                            break;
                    }
                };
                this.KeyUp += (s, e) =>
                {
                    switch (e.KeyCode)
                    {
                        case Keys.Escape:
                            Application.Exit();
                            break;
                        case Keys.A:
                            moveLeft = false;
                            break;
                        case Keys.D:
                            moveRight = false;
                            break;
                        case Keys.W:
                            moveUp = false;
                            break;
                        case Keys.S:
                            moveDown = false;
                            break;
                    }
                };
                if (moveLeft == true && pictureBox1.Left > -5)
                {
                    pictureBox1.Left -= speed;
                }
                if (moveRight == true && pictureBox1.Left < 1080)
                {
                    pictureBox1.Left += speed;
                }
                if (moveUp == true && pictureBox1.Top > 70)
                {
                    pictureBox1.Top -= speed;
                }
                if (moveDown == true && pictureBox1.Top < 743)
                {
                    pictureBox1.Top += speed;
                }
            };
        }
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }        
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            Point center = new Point(this.Width / 2, this.Height / 2);
            float angle = (float)Math.Atan2(e.Y - center.Y, e.X - center.X) * (float)(180/Math.PI);
            RotateSoldier(angle);
        }

        public void RotateSoldier(float rotationAngle)
        {
            //turn the Bitmap into a Graphics object
            Graphics g = Graphics.FromImage(pictureBox1.Image);
            g.Clear(Color.Transparent);

            //now we set the rotation point to the center of our image
            g.TranslateTransform((float)pictureBox1.Width / 2, (float)pictureBox1.Height / 2);

            //now rotate the image
            g.RotateTransform(rotationAngle);

            g.TranslateTransform(-(float)pictureBox1.Width / 2, -(float)pictureBox1.Height / 2);

            //set the InterpolationMode to HighQualityBicubic so to ensure a high
            //quality image once it is transformed to the specified size
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;

            //now draw our new image onto the graphics object
            g.DrawImage(soldierimage, 0, 0, pictureBox1.Width, pictureBox1.Height);

            //dispose of our Graphics object
            g.Dispose();

            pictureBox1.Refresh();
        }
    }
}
